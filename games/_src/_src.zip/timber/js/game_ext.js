function ext_game_global(game) {

};
function ext_preload_preload(game) {

};
function ext_levelPlay(game) {

};
function ext_levelPlay_create(game) {

};
function ext_levelPlay_update(game) {

};